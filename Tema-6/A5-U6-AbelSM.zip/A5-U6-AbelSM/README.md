# Desarrollo-Cliente
EJERCICIO 5:

Realizar un código en el que tengamos en HTML varios párrafos con un determinado texto escrito.

Crear un botón para ocultar/visualizar el párrafo que elegido.

Para ello puedes utilizar dos clases en CSS y, mediante JavaScript, se irá can1biando la clase al elemento del DOM
