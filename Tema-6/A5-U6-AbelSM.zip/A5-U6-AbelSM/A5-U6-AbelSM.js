document.getElementById("quitarQuijote").addEventListener('click', () => {
    var quijote =  document.getElementById("quijote");
    quijote.classList.toggle('ocultar')
})

document.getElementById("quitarTarzan").addEventListener('click', () => {
    let tarzan =  document.getElementById("tarzan");
    tarzan.classList.toggle('ocultar')
})

document.getElementById("quitarMowgli").addEventListener('click', () => {
    var mowgli =  document.getElementById("mowgli");
    mowgli.classList.toggle('ocultar')
})