# Desarrollo-Cliente
EJERCICIO 4:

Crear una array multidimensional que recoja los nombres de 5 alumnos y las notas obtenidas en tres módulos.

 Dicha información será introducida por el usuario y una vez finalizada la recogida de datos se mostrará el contenido del array en forma de tabla. 
 
Tabla generada por manejo del DOM
