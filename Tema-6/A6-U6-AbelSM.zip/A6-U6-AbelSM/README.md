EJERCICIO 6:

    En ocasiones, los programadores necesitan deshabilitar ciertos elementos de la interfaz dependiendo de la interacción con el usuario.

     Por ello, crear un código en JS de un botón que hace que se desactiven o activen ciertos elen1.entos de la página web, por ejemplo que active o desactive una serie de imput.

     Habilitar y deshabilitar elementos del DOM

     Mejoras propias en la actividad:
        
        a) Sólo se desactivarán los inputs que no tengan ningún valor al momento de dar click en el botón