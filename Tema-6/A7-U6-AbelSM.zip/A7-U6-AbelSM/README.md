ACTIVIDAD 7:
El Document Object Model (DOM) es una representación en forma de árbol de los elementos de una página HTML. 
Se puede manipular con JavaScript para cambiar dinámicamente la estructura y el contenido de una página. 

Realizar un código que muestre/ represente en el propio HTML  el DOM de la página HTML.

** Notas **

El código ahora mismo está hecho con varios bucles foreach anidado, de forma que sólo se puede
comprobar hasta el nodo "nieto". Lo ideal sería poder hacer esa comprobación de forma
recursiva por cada uno de los nodos que se van pasando.